package com.example.retrofitforecaster

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface ForecastAPI {

    @GET("data/2.5/forecast")
    suspend fun getHourlyForecastForNextDays(
    //fun getHourlyForecastForNextDays(
        @Query("q") city: String,
        @Query("appid") apiKey: String,
        @Query("units") units: String = "metric",
    ): Temperatures

}


val forecastApiService: ForecastAPI by lazy {
    val client = OkHttpClient.Builder()
        .build()

    Retrofit.Builder()
        .baseUrl("https://api.openweathermap.org/")
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(ForecastAPI::class.java)
}