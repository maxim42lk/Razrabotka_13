package com.example.retrofitforecaster

import android.app.Application

class MyCustomApplication : Application() {
    companion object {
        lateinit var api1: ForecastAPI
    }
    override fun onCreate() {
        super.onCreate()
        api1 = forecastApiService
    }
}